import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { FileCode, Zap, Rocket } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const steps = [
  {
    icon: FileCode,
    title: '1) Describe',
    description: 'Paste code or type what you need.',
  },
  {
    icon: Zap,
    title: '2) Receive',
    description: 'Get explanations, refactors, or fixes instantly.',
  },
  {
    icon: Rocket,
    title: '3) Apply',
    description: 'Copy, edit, and ship with confidence.',
  },
];

export function HowItWorks() {
  const sectionRef = useRef<HTMLElement>(null);
  const headingRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<(HTMLDivElement | null)[]>([]);
  const lineRef = useRef<SVGLineElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    const heading = headingRef.current;
    const cards = cardsRef.current.filter(Boolean);
    const line = lineRef.current;

    if (!section || !heading || cards.length === 0) return;

    const ctx = gsap.context(() => {
      // Heading animation
      gsap.fromTo(heading,
        { y: '6vh', opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: heading,
            start: 'top 80%',
            end: 'top 50%',
            scrub: true,
          }
        }
      );

      // Cards animation with stagger
      cards.forEach((card) => {
        gsap.fromTo(card,
          { y: '10vh', opacity: 0, scale: 0.98 },
          {
            y: 0,
            opacity: 1,
            scale: 1,
            duration: 0.8,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: card,
              start: 'top 85%',
              end: 'top 55%',
              scrub: true,
            }
          }
        );
      });

      // Line draw animation
      if (line) {
        const length = line.getTotalLength();
        gsap.set(line, { strokeDasharray: length, strokeDashoffset: length });
        gsap.to(line, {
          strokeDashoffset: 0,
          duration: 1.5,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 60%',
            end: 'top 20%',
            scrub: true,
          }
        });
      }
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="section-flowing py-32 z-[60] bg-[#070A12]"
    >
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        {/* Heading */}
        <div ref={headingRef} className="mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold text-white mb-4">
            How <span className="text-gradient">Gray Coding</span> works
          </h2>
          <p className="text-xl text-white/60">
            A simple loop: describe, receive, apply.
          </p>
        </div>

        {/* Steps */}
        <div className="relative">
          {/* Connecting Line (desktop only) */}
          <svg
            className="absolute top-24 left-0 w-full h-2 hidden lg:block"
            style={{ zIndex: 0 }}
          >
            <line
              ref={lineRef}
              x1="12.5%"
              y1="4"
              x2="87.5%"
              y2="4"
              stroke="rgba(42, 252, 154, 0.3)"
              strokeWidth="2"
              strokeLinecap="round"
            />
          </svg>

          {/* Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 relative z-10">
            {steps.map((step, i) => (
              <div
                key={step.title}
                ref={(el) => { cardsRef.current[i] = el; }}
                className="feature-card group"
              >
                <div className="w-14 h-14 rounded-xl bg-[#2AFC9A]/10 flex items-center justify-center mb-6 group-hover:bg-[#2AFC9A]/20 transition-colors">
                  <step.icon className="w-7 h-7 text-[#2AFC9A]" />
                </div>
                <h3 className="text-xl font-bold text-white mb-3">
                  {step.title}
                </h3>
                <p className="text-white/60">
                  {step.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
