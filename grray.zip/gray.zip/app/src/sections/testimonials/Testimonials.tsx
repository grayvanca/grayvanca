import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Quote, ArrowRight } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const testimonials = [
  {
    quote: "Gray Coding turned our legacy cleanup from a weeks-long task into a few focused sessions. It's like having a senior engineer on call.",
    author: 'Jordan Lee',
    role: 'Engineering Lead',
    company: 'TechCorp',
    image: '/testimonial_portrait.jpg',
  },
  {
    quote: "The code generation feature is incredible. I can describe what I need and get production-ready code in seconds.",
    author: 'Sarah Chen',
    role: 'Full Stack Developer',
    company: 'StartupXYZ',
    image: '/feature_photo_explain.jpg',
  },
  {
    quote: "Debugging used to take hours. Now I get clear explanations and fixes in minutes. Game changer for our team.",
    author: 'Michael Torres',
    role: 'Senior Developer',
    company: 'DevStudio',
    image: '/feature_photo_debug.jpg',
  },
];

export function Testimonials() {
  const sectionRef = useRef<HTMLElement>(null);
  const cardsRef = useRef<(HTMLDivElement | null)[]>([]);

  useEffect(() => {
    const section = sectionRef.current;
    const cards = cardsRef.current.filter(Boolean);

    if (!section || cards.length === 0) return;

    const ctx = gsap.context(() => {
      cards.forEach((card, i) => {
        gsap.fromTo(card,
          { y: '8vh', opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 0.8,
            delay: i * 0.15,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: card,
              start: 'top 85%',
              end: 'top 55%',
              scrub: true,
            }
          }
        );
      });
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="section-flowing py-32 z-[60] bg-[#070A12]"
    >
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        {/* Heading */}
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold text-white mb-4">
            Loved by <span className="text-gradient">developers</span>
          </h2>
          <p className="text-xl text-white/60">
            See what our community has to say.
          </p>
        </div>

        {/* Testimonials Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, i) => (
            <div
              key={testimonial.author}
              ref={(el) => { cardsRef.current[i] = el; }}
              className="feature-card relative"
            >
              <Quote className="w-10 h-10 text-[#2AFC9A]/20 mb-4" />
              
              <p className="text-white/80 text-lg leading-relaxed mb-6">
                "{testimonial.quote}"
              </p>

              <div className="flex items-center gap-4">
                <img
                  src={testimonial.image}
                  alt={testimonial.author}
                  className="w-12 h-12 rounded-full object-cover"
                />
                <div>
                  <p className="text-white font-medium">{testimonial.author}</p>
                  <p className="text-white/50 text-sm">
                    {testimonial.role}, {testimonial.company}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Featured Testimonial */}
        <div className="mt-16 feature-card overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-2">
            <div className="relative h-64 lg:h-auto">
              <img
                src="/testimonial_portrait.jpg"
                alt="Jordan Lee"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-transparent to-[#0B0F1C] lg:block hidden" />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0B0F1C] to-transparent lg:hidden" />
            </div>
            <div className="p-8 lg:p-12 flex flex-col justify-center">
              <Quote className="w-12 h-12 text-[#2AFC9A]/20 mb-6" />
              <p className="text-2xl text-white leading-relaxed mb-8">
                "Gray Coding turned our legacy cleanup from a weeks-long task into a few focused sessions. It's like having a senior engineer on call."
              </p>
              <div>
                <p className="text-white font-bold text-lg">Jordan Lee</p>
                <p className="text-white/50">Engineering Lead, TechCorp</p>
              </div>
              <button className="mt-8 flex items-center gap-2 text-[#2AFC9A] hover:gap-3 transition-all">
                Read the case study
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
