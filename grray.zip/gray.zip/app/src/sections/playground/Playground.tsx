import { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { MessageSquare, Wand2, FileCode, Bug, Send, Copy, Check } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

type AIMode = 'explain' | 'refactor' | 'generate' | 'debug';

interface ModeConfig {
  id: AIMode;
  label: string;
  icon: React.ElementType;
  placeholder: string;
}

const modes: ModeConfig[] = [
  { id: 'explain', label: 'Explain', icon: MessageSquare, placeholder: 'Paste code to explain...' },
  { id: 'refactor', label: 'Refactor', icon: Wand2, placeholder: 'Paste code to improve...' },
  { id: 'generate', label: 'Generate', icon: FileCode, placeholder: 'Describe what you need...' },
  { id: 'debug', label: 'Debug', icon: Bug, placeholder: 'Paste code with errors...' },
];

const mockResponses: Record<AIMode, string> = {
  explain: `// Gray Coding Analysis:
// This function maps user data by extracting 
// the _id and name properties from each user object.
// 
// Parameters:
//   u - user object containing _id and name
//
// Returns:
//   Object with id and name properties

function mapUser(u) {
  return { id: u._id, name: u.name };
}`,
  refactor: `// Gray Coding Refactored:
// - Used destructuring for cleaner parameter handling
// - Added type safety with JSDoc comments
// - Renamed parameter for clarity

/**
 * @param {{_id: string, name: string}} user
 * @returns {{id: string, name: string}}
 */
const mapUser = ({ _id, name }) => ({ 
  id: _id, 
  name 
});`,
  generate: `// Gray Coding Generated:
// A robust email validator with TypeScript support

/**
 * Validates an email address format
 * @param {string} email - Email to validate
 * @returns {boolean} - True if valid
 */
const validateEmail = (email) => {
  const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return regex.test(email);
};

// Usage:
// validateEmail('user@example.com'); // true`,
  debug: `// Gray Coding Debug Analysis:
// Issue: TypeError - Cannot read property of undefined
// 
// Root Cause: The 'user' object may not have 
// a 'profile' property defined.
//
// Fix: Use optional chaining (?.) to safely 
// access nested properties

// Before:
// const id = user.profile.id; // Error!

// After:
const id = user?.profile?.id;

// Alternative with default value:
const id = user?.profile?.id ?? 'default-id';`,
};

export function Playground() {
  const sectionRef = useRef<HTMLElement>(null);
  const textRef = useRef<HTMLDivElement>(null);
  const appRef = useRef<HTMLDivElement>(null);
  
  const [activeMode, setActiveMode] = useState<AIMode>('explain');
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    const section = sectionRef.current;
    const text = textRef.current;
    const app = appRef.current;

    if (!section || !text || !app) return;

    const ctx = gsap.context(() => {
      gsap.fromTo(text,
        { x: '-6vw', opacity: 0 },
        {
          x: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 70%',
            end: 'top 30%',
            scrub: true,
          }
        }
      );

      gsap.fromTo(app,
        { x: '8vw', opacity: 0, scale: 0.98 },
        {
          x: 0,
          opacity: 1,
          scale: 1,
          duration: 0.8,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 65%',
            end: 'top 25%',
            scrub: true,
          }
        }
      );
    }, section);

    return () => ctx.revert();
  }, []);

  const handleSubmit = () => {
    if (!input.trim()) return;
    setIsLoading(true);
    setTimeout(() => {
      setOutput(mockResponses[activeMode]);
      setIsLoading(false);
    }, 800);
  };

  const handleCopy = async () => {
    await navigator.clipboard.writeText(output);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const highlightCode = (code: string) => {
    return code
      .replace(/(\/\/.*$)/gm, '<span class="token-comment">$1</span>')
      .replace(/\b(function|const|let|var|return|if|else|for|while|class|import|export|from|async|await|try|catch|true|false|null|undefined)\b/g, '<span class="token-keyword">$1</span>')
      .replace(/\b([a-zA-Z_][a-zA-Z0-9_]*)\s*(?=\()/g, '<span class="token-function">$1</span>')
      .replace(/('[^']*'|"[^"]*"|`[^`]*`)/g, '<span class="token-string">$1</span>')
      .replace(/\b(\d+)\b/g, '<span class="token-number">$1</span>')
      .replace(/([{}[\]()])/g, '<span class="token-operator">$1</span>')
      .replace(/(=>|===|==|!=|!==|&&|\|\||[+\-*/=<>!&|])/g, '<span class="token-operator">$1</span>');
  };

  return (
    <section
      ref={sectionRef}
      className="section-flowing py-32 z-[60] bg-[#070A12]"
    >
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-start">
          {/* Left Text */}
          <div ref={textRef}>
            <h2 className="text-4xl sm:text-5xl font-bold text-white mb-4">
              Try it <span className="text-gradient">live</span>
            </h2>
            <p className="text-xl text-white/60 mb-8">
              Pick a mode, paste a snippet, and see the response.
            </p>
            
            <div className="space-y-4">
              <div className="flex items-center gap-3 text-white/70">
                <div className="w-8 h-8 rounded-lg bg-[#2AFC9A]/10 flex items-center justify-center">
                  <MessageSquare className="w-4 h-4 text-[#2AFC9A]" />
                </div>
                <span>Get instant explanations</span>
              </div>
              <div className="flex items-center gap-3 text-white/70">
                <div className="w-8 h-8 rounded-lg bg-[#2AFC9A]/10 flex items-center justify-center">
                  <Wand2 className="w-4 h-4 text-[#2AFC9A]" />
                </div>
                <span>Refactor with confidence</span>
              </div>
              <div className="flex items-center gap-3 text-white/70">
                <div className="w-8 h-8 rounded-lg bg-[#2AFC9A]/10 flex items-center justify-center">
                  <FileCode className="w-4 h-4 text-[#2AFC9A]" />
                </div>
                <span>Generate from descriptions</span>
              </div>
            </div>
          </div>

          {/* Right App Window */}
          <div
            ref={appRef}
            className="code-card overflow-hidden"
          >
            {/* Mode Selector */}
            <div className="code-header flex-wrap gap-2">
              {modes.map((mode) => (
                <button
                  key={mode.id}
                  onClick={() => {
                    setActiveMode(mode.id);
                    setOutput('');
                  }}
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
                    activeMode === mode.id
                      ? 'bg-[#2AFC9A]/20 text-[#2AFC9A]'
                      : 'text-white/50 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <mode.icon className="w-4 h-4" />
                  {mode.label}
                </button>
              ))}
            </div>

            {/* Input Area */}
            <div className="border-b border-white/10">
              <textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder={modes.find(m => m.id === activeMode)?.placeholder}
                className="w-full h-32 bg-transparent p-4 font-mono text-sm text-white placeholder:text-white/30 resize-none focus:outline-none"
              />
              <div className="px-4 pb-3 flex justify-end">
                <button
                  onClick={handleSubmit}
                  disabled={!input.trim() || isLoading}
                  className="flex items-center gap-2 px-4 py-2 bg-[#2AFC9A] text-[#070A12] rounded-lg font-medium text-sm disabled:opacity-50 disabled:cursor-not-allowed hover:bg-[#2AFC9A]/90 transition-colors"
                >
                  {isLoading ? (
                    <div className="w-4 h-4 border-2 border-[#070A12]/30 border-t-[#070A12] rounded-full animate-spin" />
                  ) : (
                    <Send className="w-4 h-4" />
                  )}
                  Ask Gray AI
                </button>
              </div>
            </div>

            {/* Output Area */}
            <div className="bg-[#050810]">
              <div className="flex items-center justify-between px-4 py-2 border-b border-white/5">
                <span className="text-xs text-white/40 font-mono">Output</span>
                {output && (
                  <button
                    onClick={handleCopy}
                    className="p-1.5 rounded hover:bg-white/10 transition-colors"
                  >
                    {copied ? (
                      <Check className="w-4 h-4 text-[#2AFC9A]" />
                    ) : (
                      <Copy className="w-4 h-4 text-white/40" />
                    )}
                  </button>
                )}
              </div>
              <div className="p-4 min-h-[200px] max-h-[300px] overflow-auto">
                {output ? (
                  <pre
                    className="font-mono text-sm leading-relaxed"
                    dangerouslySetInnerHTML={{ __html: highlightCode(output) }}
                  />
                ) : (
                  <p className="text-white/30 font-mono text-sm">
                    Gray Coding will respond here...
                  </p>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
