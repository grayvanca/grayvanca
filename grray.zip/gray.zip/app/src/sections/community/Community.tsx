import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Users, Share2, MessageCircle, TrendingUp, Heart } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const snippets = [
  {
    title: 'React hook for debounce',
    author: '@alex',
    likes: 234,
    comments: 45,
    language: 'TypeScript',
  },
  {
    title: 'Safe deep clone utility',
    author: '@sam',
    likes: 189,
    comments: 32,
    language: 'JavaScript',
  },
  {
    title: 'CSS grid micro-layouts',
    author: '@morgan',
    likes: 156,
    comments: 28,
    language: 'CSS',
  },
  {
    title: 'Python data validator',
    author: '@jordan',
    likes: 142,
    comments: 21,
    language: 'Python',
  },
];

const metrics = [
  { icon: Share2, value: '12k+', label: 'snippets shared' },
  { icon: MessageCircle, value: '48k+', label: 'explanations generated' },
  { icon: TrendingUp, value: '99.9%', label: 'uptime' },
];

export function Community() {
  const sectionRef = useRef<HTMLElement>(null);
  const headingRef = useRef<HTMLDivElement>(null);
  const cardRef = useRef<HTMLDivElement>(null);
  const metricsRef = useRef<(HTMLDivElement | null)[]>([]);

  useEffect(() => {
    const section = sectionRef.current;
    const heading = headingRef.current;
    const card = cardRef.current;
    const metricCards = metricsRef.current.filter(Boolean);

    if (!section || !heading || !card) return;

    const ctx = gsap.context(() => {
      gsap.fromTo(heading,
        { y: '5vh', opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 70%',
            end: 'top 40%',
            scrub: true,
          }
        }
      );

      gsap.fromTo(card,
        { x: '10vw', opacity: 0 },
        {
          x: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 65%',
            end: 'top 35%',
            scrub: true,
          }
        }
      );

      metricCards.forEach((metric, i) => {
        gsap.fromTo(metric,
          { y: '6vh', opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 0.6,
            delay: i * 0.1,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: metric,
              start: 'top 90%',
              end: 'top 70%',
              scrub: true,
            }
          }
        );
      });
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="section-flowing py-32 z-[60] bg-[#070A12]"
    >
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-start">
          {/* Left Heading */}
          <div ref={headingRef}>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-[#2AFC9A]/10 flex items-center justify-center">
                <Users className="w-5 h-5 text-[#2AFC9A]" />
              </div>
              <span className="text-[#2AFC9A] font-medium">Community</span>
            </div>
            <h2 className="text-4xl sm:text-5xl font-bold text-white mb-4">
              Built for <span className="text-gradient">teams</span> and communities
            </h2>
            <p className="text-xl text-white/60">
              Share snippets, review changes, and learn together.
            </p>
          </div>

          {/* Right Community Card */}
          <div
            ref={cardRef}
            className="code-card"
          >
            <div className="code-header">
              <span className="text-sm text-white/50">Trending Snippets</span>
            </div>
            <div className="divide-y divide-white/5">
              {snippets.map((snippet) => (
                <div
                  key={snippet.title}
                  className="p-4 hover:bg-white/5 transition-colors cursor-pointer group"
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <h4 className="text-white font-medium group-hover:text-[#2AFC9A] transition-colors">
                        {snippet.title}
                      </h4>
                      <p className="text-sm text-white/50 mt-1">{snippet.author}</p>
                    </div>
                    <span className="px-2 py-1 text-xs bg-white/5 rounded text-white/40">
                      {snippet.language}
                    </span>
                  </div>
                  <div className="flex items-center gap-4 mt-3">
                    <div className="flex items-center gap-1.5 text-white/40">
                      <Heart className="w-4 h-4" />
                      <span className="text-sm">{snippet.likes}</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-white/40">
                      <MessageCircle className="w-4 h-4" />
                      <span className="text-sm">{snippet.comments}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Metrics */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mt-16">
          {metrics.map((metric, i) => (
            <div
              key={metric.label}
              ref={(el) => { metricsRef.current[i] = el; }}
              className="feature-card flex items-center gap-4"
            >
              <div className="w-12 h-12 rounded-xl bg-[#2AFC9A]/10 flex items-center justify-center">
                <metric.icon className="w-6 h-6 text-[#2AFC9A]" />
              </div>
              <div>
                <p className="text-2xl font-bold text-white">{metric.value}</p>
                <p className="text-sm text-white/50">{metric.label}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
