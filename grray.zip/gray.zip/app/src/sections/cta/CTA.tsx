import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Link } from 'react-router-dom';
import { Sparkles, MessageSquare } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

export function CTA() {
  const sectionRef = useRef<HTMLElement>(null);
  const headlineRef = useRef<HTMLHeadingElement>(null);
  const subRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    const headline = headlineRef.current;
    const sub = subRef.current;
    const cta = ctaRef.current;

    if (!section || !headline || !sub || !cta) return;

    const ctx = gsap.context(() => {
      gsap.fromTo(headline,
        { y: '6vh', opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 70%',
            end: 'top 40%',
            scrub: true,
          }
        }
      );

      gsap.fromTo(sub,
        { y: '4vh', opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 65%',
            end: 'top 35%',
            scrub: true,
          }
        }
      );

      gsap.fromTo(cta,
        { scale: 0.98, opacity: 0 },
        {
          scale: 1,
          opacity: 1,
          duration: 0.8,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 60%',
            end: 'top 30%',
            scrub: true,
          }
        }
      );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="section-flowing py-32 z-[60] bg-[#070A12]"
    >
      <div className="max-w-4xl mx-auto px-6 lg:px-12 text-center">
        <h2
          ref={headlineRef}
          className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-6"
        >
          Ready to ship <span className="text-gradient">better code?</span>
        </h2>
        
        <p
          ref={subRef}
          className="text-xl text-white/60 mb-10 max-w-2xl mx-auto"
        >
          Join thousands of developers using Gray Coding every day.
        </p>

        <div ref={ctaRef} className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <Link to="/assistant" className="btn-primary flex items-center gap-2">
            <Sparkles className="w-5 h-5" />
            Start Free
          </Link>
          <button className="flex items-center gap-2 text-white/70 hover:text-white transition-colors">
            <MessageSquare className="w-5 h-5" />
            Talk to Sales
          </button>
        </div>
      </div>
    </section>
  );
}
