import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { CodeCard } from '@/components/code/CodeCard';

gsap.registerPlugin(ScrollTrigger);

const codeExample = `// Gray Coding
const validateEmail = (email) =>
  /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);`;

export function FeatureGenerate() {
  const sectionRef = useRef<HTMLElement>(null);
  const photoRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const badgeRef = useRef<HTMLDivElement>(null);
  const headlineRef = useRef<HTMLHeadingElement>(null);
  const bodyRef = useRef<HTMLParagraphElement>(null);
  const cardRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    const photo = photoRef.current;
    const content = contentRef.current;
    const badge = badgeRef.current;
    const headline = headlineRef.current;
    const body = bodyRef.current;
    const card = cardRef.current;

    if (!section || !photo || !content || !badge || !headline || !body || !card) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        }
      });

      // ENTRANCE (0-30%)
      scrollTl
        .fromTo(photo,
          { x: '-60vw', opacity: 0 },
          { x: 0, opacity: 1, ease: 'none' },
          0
        )
        .fromTo(content,
          { x: '60vw', opacity: 0 },
          { x: 0, opacity: 1, ease: 'none' },
          0
        )
        .fromTo(badge,
          { x: '10vw', opacity: 0 },
          { x: 0, opacity: 1, ease: 'none' },
          0.05
        )
        .fromTo(headline,
          { x: '10vw', opacity: 0 },
          { x: 0, opacity: 1, ease: 'none' },
          0.08
        )
        .fromTo(body,
          { x: '8vw', opacity: 0 },
          { x: 0, opacity: 1, ease: 'none' },
          0.12
        )
        .fromTo(card,
          { x: '12vw', y: '6vh', opacity: 0, scale: 0.98 },
          { x: 0, y: 0, opacity: 1, scale: 1, ease: 'none' },
          0.15
        );

      // EXIT (70-100%)
      scrollTl
        .to(photo,
          { x: '-18vw', opacity: 0, ease: 'power2.in' },
          0.7
        )
        .to(content,
          { x: '18vw', opacity: 0, ease: 'power2.in' },
          0.7
        )
        .to([badge, headline],
          { y: '-10vh', opacity: 0, ease: 'power2.in' },
          0.72
        )
        .to(body,
          { opacity: 0, ease: 'power2.in' },
          0.74
        )
        .to(card,
          { y: '10vh', opacity: 0, ease: 'power2.in' },
          0.75
        );

    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="section-pinned flex z-40"
    >
      {/* Left Photo Panel */}
      <div
        ref={photoRef}
        className="absolute left-0 top-0 w-1/2 h-full"
      >
        <img
          src="/feature_photo_generate.jpg"
          alt="Developer at workstation"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-transparent to-[#070A12]" />
      </div>

      {/* Right Content Panel */}
      <div
        ref={contentRef}
        className="absolute right-0 top-0 w-1/2 h-full bg-[#070A12] flex items-center"
      >
        <div className="px-8 lg:px-16 xl:px-24 max-w-xl">
          {/* Badge */}
          <div ref={badgeRef} className="mb-6">
            <span className="badge-accent">03 / Generate</span>
          </div>

          {/* Headline */}
          <h2
            ref={headlineRef}
            className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white leading-tight mb-6"
          >
            Write code from a{' '}
            <span className="text-gradient">description</span>{' '}
            in any language.
          </h2>

          {/* Body */}
          <p ref={bodyRef} className="text-lg text-white/60 mb-8">
            Describe what you need. Gray Coding outputs idiomatic code with comments, types, and tests.
          </p>

          {/* Code Card */}
          <div ref={cardRef}>
            <CodeCard title="Generated snippet" code={codeExample} />
          </div>
        </div>
      </div>
    </section>
  );
}
