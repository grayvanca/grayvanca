import { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ChevronDown, HelpCircle } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const faqs = [
  {
    question: 'Is there a free tier?',
    answer: 'Yes. Start with 50 requests per month at no cost. No credit card required.',
  },
  {
    question: 'Can I use it in my IDE?',
    answer: 'We offer extensions for VS Code and JetBrains IDEs. Install from the marketplace and start coding with AI assistance right in your editor.',
  },
  {
    question: 'Does it support my language?',
    answer: 'Gray Coding supports JavaScript, TypeScript, Python, Go, Rust, Java, C++, C#, Ruby, PHP, and more. We\'re constantly adding new languages.',
  },
  {
    question: 'Is my code kept private?',
    answer: 'Yes. We do not train on your code. Your snippets are encrypted and only accessible to you. Enterprise plans offer additional security features.',
  },
  {
    question: 'Can I self-host?',
    answer: 'Team plans include a self-hosted option for organizations with strict compliance requirements. Contact sales for details.',
  },
  {
    question: 'How do I cancel?',
    answer: 'Cancel anytime from your account settings. You\'ll continue to have access until the end of your billing period.',
  },
];

export function FAQ() {
  const sectionRef = useRef<HTMLElement>(null);
  const headingRef = useRef<HTMLDivElement>(null);
  const itemsRef = useRef<(HTMLDivElement | null)[]>([]);
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  useEffect(() => {
    const section = sectionRef.current;
    const heading = headingRef.current;
    const items = itemsRef.current.filter(Boolean);

    if (!section || !heading || items.length === 0) return;

    const ctx = gsap.context(() => {
      gsap.fromTo(heading,
        { y: '4vh', opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 70%',
            end: 'top 40%',
            scrub: true,
          }
        }
      );

      items.forEach((item, i) => {
        gsap.fromTo(item,
          { y: '3vh', opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 0.6,
            delay: i * 0.05,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: item,
              start: 'top 90%',
              end: 'top 70%',
              scrub: true,
            }
          }
        );
      });
    }, section);

    return () => ctx.revert();
  }, []);

  const toggleItem = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section
      ref={sectionRef}
      className="section-flowing py-32 z-[60] bg-[#070A12]"
    >
      <div className="max-w-4xl mx-auto px-6 lg:px-12">
        {/* Heading */}
        <div ref={headingRef} className="text-center mb-16">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-xl bg-[#2AFC9A]/10 flex items-center justify-center">
              <HelpCircle className="w-5 h-5 text-[#2AFC9A]" />
            </div>
          </div>
          <h2 className="text-4xl sm:text-5xl font-bold text-white mb-4">
            Questions <span className="text-gradient">&</span> Answers
          </h2>
          <p className="text-xl text-white/60">
            Everything you need to know before you start.
          </p>
        </div>

        {/* FAQ Items */}
        <div className="space-y-4">
          {faqs.map((faq, i) => (
            <div
              key={i}
              ref={(el) => { itemsRef.current[i] = el; }}
              className="feature-card overflow-hidden"
            >
              <button
                onClick={() => toggleItem(i)}
                className="w-full flex items-center justify-between p-6 text-left"
              >
                <span className="text-lg font-medium text-white pr-4">
                  {faq.question}
                </span>
                <ChevronDown
                  className={`w-5 h-5 text-[#2AFC9A] flex-shrink-0 transition-transform duration-300 ${
                    openIndex === i ? 'rotate-180' : ''
                  }`}
                />
              </button>
              <div
                className={`overflow-hidden transition-all duration-300 ${
                  openIndex === i ? 'max-h-48' : 'max-h-0'
                }`}
              >
                <p className="px-6 pb-6 text-white/60">
                  {faq.answer}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
