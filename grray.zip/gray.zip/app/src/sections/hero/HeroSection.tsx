import { useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ChevronDown, Sparkles } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

export function HeroSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const headlineRef = useRef<HTMLHeadingElement>(null);
  const subheadRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);
  const scrollCueRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    const headline = headlineRef.current;
    const subhead = subheadRef.current;
    const cta = ctaRef.current;
    const scrollCue = scrollCueRef.current;

    if (!section || !headline || !subhead || !cta || !scrollCue) return;

    const ctx = gsap.context(() => {
      // Initial load animation
      const loadTl = gsap.timeline({ defaults: { ease: 'power3.out' } });

      // Split headline into words
      const words = headline.querySelectorAll('.word');
      
      loadTl
        .fromTo(words, 
          { y: 24, opacity: 0 },
          { y: 0, opacity: 1, stagger: 0.05, duration: 0.8 }
        )
        .fromTo(subhead,
          { y: 16, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.6 },
          '-=0.4'
        )
        .fromTo(cta,
          { y: 18, scale: 0.98, opacity: 0 },
          { y: 0, scale: 1, opacity: 1, duration: 0.5 },
          '-=0.3'
        )
        .fromTo(scrollCue,
          { opacity: 0 },
          { opacity: 1, duration: 0.4 },
          '-=0.1'
        );

      // Scroll-driven exit animation
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
          onLeaveBack: () => {
            // Reset all elements when scrolling back to top
            gsap.set([words, subhead, cta], { opacity: 1, y: 0 });
          }
        }
      });

      // ENTRANCE (0-30%): Hold at visible state (already animated on load)
      // SETTLE (30-70%): Hold
      // EXIT (70-100%): Animate out
      
      scrollTl
        .fromTo(headline,
          { y: 0, opacity: 1 },
          { y: '-22vh', opacity: 0, ease: 'power2.in' },
          0.7
        )
        .fromTo(subhead,
          { y: 0, opacity: 1 },
          { y: '-18vh', opacity: 0, ease: 'power2.in' },
          0.72
        )
        .fromTo(cta,
          { y: 0, opacity: 1 },
          { y: '-10vh', opacity: 0, ease: 'power2.in' },
          0.74
        )
        .fromTo(scrollCue,
          { opacity: 1 },
          { opacity: 0 },
          0.7
        );

    }, section);

    return () => ctx.revert();
  }, []);

  const headlineText = "Your AI-Powered Development Companion.";
  const words = headlineText.split(' ');

  return (
    <section
      ref={sectionRef}
      className="section-pinned flex items-center justify-center z-10"
    >
      <div className="relative w-full max-w-6xl mx-auto px-6 text-center">
        {/* Headline */}
        <h1
          ref={headlineRef}
          className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold text-white leading-tight mb-6"
        >
          {words.map((word, i) => (
            <span key={i} className="word inline-block mr-[0.25em]">
              {word === 'AI-Powered' ? (
                <span className="text-gradient">{word}</span>
              ) : (
                word
              )}
            </span>
          ))}
        </h1>

        {/* Subheadline */}
        <p
          ref={subheadRef}
          className="text-lg sm:text-xl text-white/60 max-w-2xl mx-auto mb-10"
        >
          Explain, refactor, generate, and debug—right inside your workflow.
        </p>

        {/* CTA Buttons */}
        <div ref={ctaRef} className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <Link to="/assistant" className="btn-primary flex items-center gap-2">
            <Sparkles className="w-4 h-4" />
            Start Free
          </Link>
          <Link to="/assistant" className="btn-secondary flex items-center gap-2">
            Explore the Assistant
          </Link>
        </div>
      </div>

      {/* Scroll Cue */}
      <div
        ref={scrollCueRef}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-white/40"
      >
        <span className="text-xs uppercase tracking-widest">Scroll</span>
        <ChevronDown className="w-5 h-5 animate-bounce" />
      </div>
    </section>
  );
}
