import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AuroraBackground } from '@/components/aurora/AuroraBackground';
import { Header } from '@/components/navigation/Header';
import { LandingPage } from '@/pages/LandingPage';
import { AssistantPage } from '@/pages/AssistantPage';
import { CommunityPage } from '@/pages/CommunityPage';
import { LearningPage } from '@/pages/LearningPage';
import { AuthPage } from '@/pages/AuthPage';

function App() {
  return (
    <Router>
      <div className="relative min-h-screen">
        {/* Aurora Background - Fixed behind all content */}
        <AuroraBackground />
        
        {/* Grain Overlay */}
        <div className="grain-overlay" />
        
        {/* Navigation Header */}
        <Header />
        
        {/* Main Content */}
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route path="/assistant" element={<AssistantPage />} />
          <Route path="/community" element={<CommunityPage />} />
          <Route path="/learning" element={<LearningPage />} />
          <Route path="/login" element={<AuthPage />} />
          <Route path="/register" element={<AuthPage />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
