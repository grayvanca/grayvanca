import { useState } from 'react';
import { 
  Search, 
  MessageSquare, 
  Heart, 
  TrendingUp, 
  Clock, 
  Plus,
  User
} from 'lucide-react';

interface Post {
  id: string;
  title: string;
  content: string;
  author: {
    name: string;
    avatar?: string;
  };
  category: string;
  tags: string[];
  upvotes: number;
  comments: number;
  createdAt: string;
}

const categories = [
  { id: 'all', label: 'All Posts' },
  { id: 'javascript', label: 'JavaScript' },
  { id: 'python', label: 'Python' },
  { id: 'typescript', label: 'TypeScript' },
  { id: 'rust', label: 'Rust' },
  { id: 'go', label: 'Go' },
  { id: 'showcase', label: 'Showcase' },
  { id: 'help', label: 'Help' },
];

const mockPosts: Post[] = [
  {
    id: '1',
    title: 'How to optimize React re-renders with useMemo?',
    content: 'I\'ve been struggling with performance in my React app. What are the best practices for using useMemo and useCallback effectively?',
    author: { name: 'alex_dev' },
    category: 'javascript',
    tags: ['react', 'performance', 'hooks'],
    upvotes: 45,
    comments: 12,
    createdAt: '2 hours ago',
  },
  {
    id: '2',
    title: 'Share your favorite Python one-liners!',
    content: 'Let\'s collect some elegant Python one-liners. Here\'s mine: `flatten = lambda l: [item for sublist in l for item in sublist]`',
    author: { name: 'pythonista' },
    category: 'python',
    tags: ['python', 'tips', 'code-golf'],
    upvotes: 128,
    comments: 34,
    createdAt: '5 hours ago',
  },
  {
    id: '3',
    title: 'TypeScript 5.0 new features overview',
    content: 'TypeScript 5.0 brings decorators, const type parameters, and more. Here\'s a comprehensive breakdown...',
    author: { name: 'ts_guru' },
    category: 'typescript',
    tags: ['typescript', 'news', 'features'],
    upvotes: 89,
    comments: 23,
    createdAt: '1 day ago',
  },
  {
    id: '4',
    title: 'Rust vs Go for backend services - your thoughts?',
    content: 'I\'m starting a new project and can\'t decide between Rust and Go. What are your experiences?',
    author: { name: 'backend_dev' },
    category: 'go',
    tags: ['rust', 'go', 'backend', 'discussion'],
    upvotes: 67,
    comments: 45,
    createdAt: '2 days ago',
  },
  {
    id: '5',
    title: 'Built a CLI tool with Rust - feedback welcome!',
    content: 'Just released my first Rust CLI tool for managing dotfiles. Would love to get some feedback from the community!',
    author: { name: 'rustacean' },
    category: 'showcase',
    tags: ['rust', 'cli', 'showcase', 'oss'],
    upvotes: 156,
    comments: 28,
    createdAt: '3 days ago',
  },
];

export function CommunityPage() {
  const [activeCategory, setActiveCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'trending' | 'new'>('trending');
  const [upvotedPosts, setUpvotedPosts] = useState<Set<string>>(new Set());

  const filteredPosts = mockPosts.filter(post => {
    const matchesCategory = activeCategory === 'all' || post.category === activeCategory;
    const matchesSearch = post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         post.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         post.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCategory && matchesSearch;
  });

  const toggleUpvote = (postId: string) => {
    setUpvotedPosts(prev => {
      const newSet = new Set(prev);
      if (newSet.has(postId)) {
        newSet.delete(postId);
      } else {
        newSet.add(postId);
      }
      return newSet;
    });
  };

  return (
    <div className="min-h-screen pt-20 pb-8 bg-[#070A12]">
      <div className="max-w-7xl mx-auto px-4 lg:px-8">
        {/* Header */}
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold text-white mb-2">Community Hub</h1>
            <p className="text-white/50">Share, learn, and connect with fellow developers</p>
          </div>
          <button className="btn-primary flex items-center gap-2 self-start">
            <Plus className="w-5 h-5" />
            New Post
          </button>
        </div>

        {/* Search and Filter Bar */}
        <div className="flex flex-col sm:flex-row gap-4 mb-8">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-white/40" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search posts, tags, or topics..."
              className="input-dark w-full pl-12"
            />
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => setSortBy('trending')}
              className={`flex items-center gap-2 px-4 py-3 rounded-xl font-medium transition-all ${
                sortBy === 'trending'
                  ? 'bg-[#2AFC9A]/20 text-[#2AFC9A]'
                  : 'bg-white/5 text-white/70 hover:bg-white/10'
              }`}
            >
              <TrendingUp className="w-4 h-4" />
              Trending
            </button>
            <button
              onClick={() => setSortBy('new')}
              className={`flex items-center gap-2 px-4 py-3 rounded-xl font-medium transition-all ${
                sortBy === 'new'
                  ? 'bg-[#2AFC9A]/20 text-[#2AFC9A]'
                  : 'bg-white/5 text-white/70 hover:bg-white/10'
              }`}
            >
              <Clock className="w-4 h-4" />
              New
            </button>
          </div>
        </div>

        {/* Category Pills */}
        <div className="flex flex-wrap gap-2 mb-8">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                activeCategory === cat.id
                  ? 'bg-[#2AFC9A] text-[#070A12]'
                  : 'bg-white/5 text-white/70 hover:bg-white/10 hover:text-white'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Posts Grid */}
        <div className="grid grid-cols-1 gap-4">
          {filteredPosts.map((post) => (
            <div
              key={post.id}
              className="feature-card group cursor-pointer"
            >
              <div className="flex gap-4">
                {/* Upvote Section */}
                <div className="flex flex-col items-center gap-1">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleUpvote(post.id);
                    }}
                    className={`p-2 rounded-lg transition-all ${
                      upvotedPosts.has(post.id)
                        ? 'bg-[#2AFC9A]/20 text-[#2AFC9A]'
                        : 'bg-white/5 text-white/50 hover:bg-white/10'
                    }`}
                  >
                    <Heart className={`w-5 h-5 ${upvotedPosts.has(post.id) ? 'fill-current' : ''}`} />
                  </button>
                  <span className="text-sm font-medium text-white">
                    {post.upvotes + (upvotedPosts.has(post.id) ? 1 : 0)}
                  </span>
                </div>

                {/* Content */}
                <div className="flex-1">
                  <h3 className="text-lg font-semibold text-white group-hover:text-[#2AFC9A] transition-colors mb-2">
                    {post.title}
                  </h3>
                  <p className="text-white/60 text-sm line-clamp-2 mb-3">
                    {post.content}
                  </p>

                  {/* Tags */}
                  <div className="flex flex-wrap gap-2 mb-3">
                    {post.tags.map((tag) => (
                      <span
                        key={tag}
                        className="px-2 py-1 text-xs bg-white/5 text-white/50 rounded"
                      >
                        #{tag}
                      </span>
                    ))}
                  </div>

                  {/* Meta */}
                  <div className="flex items-center gap-4 text-sm text-white/40">
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded-full bg-[#2AFC9A]/10 flex items-center justify-center">
                        <User className="w-3 h-3 text-[#2AFC9A]" />
                      </div>
                      <span>{post.author.name}</span>
                    </div>
                    <span>•</span>
                    <span>{post.createdAt}</span>
                    <span>•</span>
                    <div className="flex items-center gap-1">
                      <MessageSquare className="w-4 h-4" />
                      <span>{post.comments} comments</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Empty State */}
        {filteredPosts.length === 0 && (
          <div className="text-center py-16">
            <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center mx-auto mb-4">
              <Search className="w-8 h-8 text-white/30" />
            </div>
            <h3 className="text-xl font-semibold text-white mb-2">No posts found</h3>
            <p className="text-white/50">Try adjusting your search or filters</p>
          </div>
        )}
      </div>
    </div>
  );
}
