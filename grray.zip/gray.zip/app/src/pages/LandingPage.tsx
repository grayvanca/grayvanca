import { useEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { HeroSection } from '@/sections/hero/HeroSection';
import { FeatureExplain } from '@/sections/features/FeatureExplain';
import { FeatureRefactor } from '@/sections/features/FeatureRefactor';
import { FeatureGenerate } from '@/sections/features/FeatureGenerate';
import { FeatureDebug } from '@/sections/features/FeatureDebug';
import { HowItWorks } from '@/sections/how-it-works/HowItWorks';
import { Playground } from '@/sections/playground/Playground';
import { Community } from '@/sections/community/Community';
import { Pricing } from '@/sections/pricing/Pricing';
import { Testimonials } from '@/sections/testimonials/Testimonials';
import { FAQ } from '@/sections/faq/FAQ';
import { CTA } from '@/sections/cta/CTA';
import { Footer } from '@/sections/footer/Footer';

gsap.registerPlugin(ScrollTrigger);

export function LandingPage() {
  useEffect(() => {
    // Configure global snap for pinned sections
    const setupGlobalSnap = () => {
      const pinned = ScrollTrigger.getAll()
        .filter(st => st.vars.pin)
        .sort((a, b) => a.start - b.start);
      
      const maxScroll = ScrollTrigger.maxScroll(window);
      if (!maxScroll || pinned.length === 0) return;

      const pinnedRanges = pinned.map(st => ({
        start: st.start / maxScroll,
        end: (st.end ?? st.start) / maxScroll,
        center: (st.start + ((st.end ?? st.start) - st.start) * 0.5) / maxScroll,
      }));

      ScrollTrigger.create({
        snap: {
          snapTo: (value: number) => {
            const inPinned = pinnedRanges.some(
              r => value >= r.start - 0.02 && value <= r.end + 0.02
            );
            if (!inPinned) return value;

            const target = pinnedRanges.reduce(
              (closest, r) =>
                Math.abs(r.center - value) < Math.abs(closest - value)
                  ? r.center
                  : closest,
              pinnedRanges[0]?.center ?? 0
            );
            return target;
          },
          duration: { min: 0.15, max: 0.35 },
          delay: 0,
          ease: 'power2.out',
        },
      });
    };

    // Delay to ensure all ScrollTriggers are created
    const timer = setTimeout(setupGlobalSnap, 100);

    return () => {
      clearTimeout(timer);
      ScrollTrigger.getAll().forEach(st => st.kill());
    };
  }, []);

  return (
    <main className="relative">
      {/* Pinned Sections with z-index stacking */}
      <HeroSection />
      <FeatureExplain />
      <FeatureRefactor />
      <FeatureGenerate />
      <FeatureDebug />
      
      {/* Flowing Sections */}
      <HowItWorks />
      <Playground />
      <Community />
      <Pricing />
      <Testimonials />
      <FAQ />
      <CTA />
      <Footer />
    </main>
  );
}
