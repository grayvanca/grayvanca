import { useState } from 'react';
import { 
  Search, 
  BookOpen, 
  Clock, 
  BarChart3, 
  Play,
  Star,
  ChevronRight,
  Filter,
  Code2
} from 'lucide-react';

interface Tutorial {
  id: string;
  title: string;
  description: string;
  category: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  duration: string;
  rating: number;
  students: number;
  image?: string;
}

const categories = [
  { id: 'all', label: 'All Courses' },
  { id: 'javascript', label: 'JavaScript' },
  { id: 'python', label: 'Python' },
  { id: 'react', label: 'React' },
  { id: 'typescript', label: 'TypeScript' },
  { id: 'algorithms', label: 'Algorithms' },
  { id: 'system-design', label: 'System Design' },
];

const difficulties = [
  { id: 'all', label: 'All Levels' },
  { id: 'beginner', label: 'Beginner' },
  { id: 'intermediate', label: 'Intermediate' },
  { id: 'advanced', label: 'Advanced' },
];

const tutorials: Tutorial[] = [
  {
    id: '1',
    title: 'JavaScript Fundamentals',
    description: 'Master the basics of JavaScript including variables, functions, and control flow.',
    category: 'javascript',
    difficulty: 'beginner',
    duration: '4 hours',
    rating: 4.8,
    students: 12500,
  },
  {
    id: '2',
    title: 'React Hooks Deep Dive',
    description: 'Learn useState, useEffect, useContext, and custom hooks with real-world examples.',
    category: 'react',
    difficulty: 'intermediate',
    duration: '6 hours',
    rating: 4.9,
    students: 8900,
  },
  {
    id: '3',
    title: 'Python for Data Science',
    description: 'Introduction to pandas, numpy, and matplotlib for data analysis.',
    category: 'python',
    difficulty: 'beginner',
    duration: '8 hours',
    rating: 4.7,
    students: 15200,
  },
  {
    id: '4',
    title: 'TypeScript Advanced Patterns',
    description: 'Master generics, conditional types, and type inference.',
    category: 'typescript',
    difficulty: 'advanced',
    duration: '5 hours',
    rating: 4.9,
    students: 5600,
  },
  {
    id: '5',
    title: 'Data Structures & Algorithms',
    description: 'Essential algorithms and data structures for coding interviews.',
    category: 'algorithms',
    difficulty: 'intermediate',
    duration: '12 hours',
    rating: 4.8,
    students: 21000,
  },
  {
    id: '6',
    title: 'System Design Fundamentals',
    description: 'Learn to design scalable distributed systems.',
    category: 'system-design',
    difficulty: 'advanced',
    duration: '10 hours',
    rating: 4.9,
    students: 7800,
  },
];

const getDifficultyColor = (difficulty: string) => {
  switch (difficulty) {
    case 'beginner':
      return 'text-green-400 bg-green-400/10';
    case 'intermediate':
      return 'text-yellow-400 bg-yellow-400/10';
    case 'advanced':
      return 'text-red-400 bg-red-400/10';
    default:
      return 'text-white/50 bg-white/5';
  }
};

export function LearningPage() {
  const [activeCategory, setActiveCategory] = useState('all');
  const [activeDifficulty, setActiveDifficulty] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredTutorials = tutorials.filter((tutorial) => {
    const matchesCategory = activeCategory === 'all' || tutorial.category === activeCategory;
    const matchesDifficulty = activeDifficulty === 'all' || tutorial.difficulty === activeDifficulty;
    const matchesSearch = tutorial.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         tutorial.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesDifficulty && matchesSearch;
  });

  return (
    <div className="min-h-screen pt-20 pb-8 bg-[#070A12]">
      <div className="max-w-7xl mx-auto px-4 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">Learning Hub</h1>
          <p className="text-white/50">Master new skills with our curated tutorials and courses</p>
        </div>

        {/* Search Bar */}
        <div className="relative mb-8">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-white/40" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search tutorials, topics, or instructors..."
            className="input-dark w-full pl-12"
          />
        </div>

        {/* Filters */}
        <div className="flex flex-col lg:flex-row gap-4 mb-8">
          {/* Category Filter */}
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-3">
              <Filter className="w-4 h-4 text-white/50" />
              <span className="text-sm text-white/50">Category</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {categories.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setActiveCategory(cat.id)}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                    activeCategory === cat.id
                      ? 'bg-[#2AFC9A] text-[#070A12]'
                      : 'bg-white/5 text-white/70 hover:bg-white/10 hover:text-white'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>
          </div>

          {/* Difficulty Filter */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <BarChart3 className="w-4 h-4 text-white/50" />
              <span className="text-sm text-white/50">Difficulty</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {difficulties.map((diff) => (
                <button
                  key={diff.id}
                  onClick={() => setActiveDifficulty(diff.id)}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                    activeDifficulty === diff.id
                      ? 'bg-[#2AFC9A] text-[#070A12]'
                      : 'bg-white/5 text-white/70 hover:bg-white/10 hover:text-white'
                  }`}
                >
                  {diff.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Featured Course */}
        <div className="feature-card mb-8 overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-2">
            <div className="p-8 flex flex-col justify-center">
              <span className="badge-accent w-fit mb-4">Featured</span>
              <h2 className="text-2xl font-bold text-white mb-3">
                Complete React Developer Course 2026
              </h2>
              <p className="text-white/60 mb-6">
                From beginner to advanced. Learn React, Redux, Hooks, GraphQL, and more with hands-on projects.
              </p>
              <div className="flex items-center gap-6 mb-6">
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-white/50" />
                  <span className="text-sm text-white/50">24 hours</span>
                </div>
                <div className="flex items-center gap-2">
                  <Star className="w-4 h-4 text-yellow-400" />
                  <span className="text-sm text-white">4.9</span>
                </div>
                <div className="flex items-center gap-2">
                  <BookOpen className="w-4 h-4 text-white/50" />
                  <span className="text-sm text-white/50">15,000+ students</span>
                </div>
              </div>
              <button className="btn-primary w-fit flex items-center gap-2">
                <Play className="w-4 h-4" />
                Start Learning
              </button>
            </div>
            <div className="bg-gradient-to-br from-[#2AFC9A]/20 to-[#00D4FF]/20 flex items-center justify-center p-8">
              <div className="w-32 h-32 rounded-2xl bg-[#2AFC9A]/10 flex items-center justify-center">
                <Code2 className="w-16 h-16 text-[#2AFC9A]" />
              </div>
            </div>
          </div>
        </div>

        {/* Courses Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredTutorials.map((tutorial) => (
            <div
              key={tutorial.id}
              className="feature-card group cursor-pointer"
            >
              {/* Course Header */}
              <div className="h-32 bg-gradient-to-br from-[#2AFC9A]/10 to-[#00D4FF]/10 rounded-t-xl flex items-center justify-center mb-4">
                <Code2 className="w-12 h-12 text-[#2AFC9A]/50" />
              </div>

              {/* Content */}
              <div className="p-4">
                <div className="flex items-center gap-2 mb-3">
                  <span className={`px-2 py-1 text-xs rounded-full capitalize ${getDifficultyColor(tutorial.difficulty)}`}>
                    {tutorial.difficulty}
                  </span>
                  <span className="text-xs text-white/40 capitalize">
                    {tutorial.category}
                  </span>
                </div>

                <h3 className="text-lg font-semibold text-white group-hover:text-[#2AFC9A] transition-colors mb-2">
                  {tutorial.title}
                </h3>
                <p className="text-white/50 text-sm mb-4 line-clamp-2">
                  {tutorial.description}
                </p>

                {/* Meta */}
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-1">
                      <Clock className="w-4 h-4 text-white/40" />
                      <span className="text-white/50">{tutorial.duration}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Star className="w-4 h-4 text-yellow-400" />
                      <span className="text-white">{tutorial.rating}</span>
                    </div>
                  </div>
                  <ChevronRight className="w-5 h-5 text-white/30 group-hover:text-[#2AFC9A] group-hover:translate-x-1 transition-all" />
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Empty State */}
        {filteredTutorials.length === 0 && (
          <div className="text-center py-16">
            <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center mx-auto mb-4">
              <Search className="w-8 h-8 text-white/30" />
            </div>
            <h3 className="text-xl font-semibold text-white mb-2">No courses found</h3>
            <p className="text-white/50">Try adjusting your filters</p>
          </div>
        )}
      </div>
    </div>
  );
}
