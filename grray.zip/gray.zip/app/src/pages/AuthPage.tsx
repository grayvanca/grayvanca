import { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  Code2, 
  Eye, 
  EyeOff, 
  Github, 
  Mail,
  ArrowRight,
  CheckCircle2
} from 'lucide-react';

export function AuthPage() {
  const [isLogin, setIsLogin] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [agreed, setAgreed] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle authentication
    console.log('Auth submitted:', { email, password, name });
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#070A12] px-4 py-20">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <Link to="/" className="inline-flex items-center gap-2 mb-6">
            <div className="w-10 h-10 rounded-xl bg-[#2AFC9A]/10 flex items-center justify-center">
              <Code2 className="w-6 h-6 text-[#2AFC9A]" />
            </div>
            <span className="text-2xl font-bold text-white">
              Gray<span className="text-[#2AFC9A]">Coding</span>
            </span>
          </Link>
          <h1 className="text-2xl font-bold text-white mb-2">
            {isLogin ? 'Welcome back' : 'Create your account'}
          </h1>
          <p className="text-white/50">
            {isLogin 
              ? 'Sign in to continue coding with AI' 
              : 'Start your AI-powered coding journey'}
          </p>
        </div>

        {/* Social Auth */}
        <div className="flex gap-3 mb-6">
          <button className="flex-1 flex items-center justify-center gap-2 p-3 bg-white/5 border border-white/10 rounded-xl text-white/70 hover:bg-white/10 hover:text-white transition-all">
            <Github className="w-5 h-5" />
            <span className="text-sm font-medium">GitHub</span>
          </button>
          <button className="flex-1 flex items-center justify-center gap-2 p-3 bg-white/5 border border-white/10 rounded-xl text-white/70 hover:bg-white/10 hover:text-white transition-all">
            <Mail className="w-5 h-5" />
            <span className="text-sm font-medium">Google</span>
          </button>
        </div>

        {/* Divider */}
        <div className="flex items-center gap-4 mb-6">
          <div className="flex-1 h-px bg-white/10" />
          <span className="text-sm text-white/40">or continue with email</span>
          <div className="flex-1 h-px bg-white/10" />
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          {!isLogin && (
            <div>
              <label className="block text-sm text-white/70 mb-2">Full Name</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="John Doe"
                className="input-dark w-full"
                required={!isLogin}
              />
            </div>
          )}

          <div>
            <label className="block text-sm text-white/70 mb-2">Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@example.com"
              className="input-dark w-full"
              required
            />
          </div>

          <div>
            <label className="block text-sm text-white/70 mb-2">Password</label>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="input-dark w-full pr-12"
                required
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 p-1 text-white/40 hover:text-white transition-colors"
              >
                {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
              </button>
            </div>
          </div>

          {!isLogin && (
            <div className="flex items-start gap-3">
              <button
                type="button"
                onClick={() => setAgreed(!agreed)}
                className={`mt-0.5 w-5 h-5 rounded border flex items-center justify-center transition-all ${
                  agreed 
                    ? 'bg-[#2AFC9A] border-[#2AFC9A]' 
                    : 'border-white/20 hover:border-white/40'
                }`}
              >
                {agreed && <CheckCircle2 className="w-3.5 h-3.5 text-[#070A12]" />}
              </button>
              <p className="text-sm text-white/50">
                I agree to the{' '}
                <Link to="#" className="text-[#2AFC9A] hover:underline">Terms of Service</Link>
                {' '}and{' '}
                <Link to="#" className="text-[#2AFC9A] hover:underline">Privacy Policy</Link>
              </p>
            </div>
          )}

          <button
            type="submit"
            disabled={!isLogin && !agreed}
            className="w-full btn-primary flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isLogin ? 'Sign In' : 'Create Account'}
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        {/* Toggle */}
        <p className="text-center mt-6 text-white/50">
          {isLogin ? "Don't have an account?" : 'Already have an account?'}{' '}
          <button
            onClick={() => setIsLogin(!isLogin)}
            className="text-[#2AFC9A] hover:underline font-medium"
          >
            {isLogin ? 'Sign up' : 'Sign in'}
          </button>
        </p>

        {/* Back to Home */}
        <div className="text-center mt-8">
          <Link to="/" className="text-sm text-white/40 hover:text-white transition-colors">
            ← Back to home
          </Link>
        </div>
      </div>
    </div>
  );
}
