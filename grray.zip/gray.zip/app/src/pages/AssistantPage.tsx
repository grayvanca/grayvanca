import { useState, useRef, useEffect } from 'react';
import { 
  MessageSquare, 
  Wand2, 
  FileCode, 
  Bug, 
  Send, 
  Copy, 
  History, 
  Trash2, 
  ChevronDown,
  Sparkles
} from 'lucide-react';
import { CodeCard } from '@/components/code/CodeCard';

type AIMode = 'explain' | 'refactor' | 'generate' | 'debug';
type Language = 'javascript' | 'typescript' | 'python' | 'java' | 'cpp' | 'go' | 'rust';

interface ChatMessage {
  id: string;
  mode: AIMode;
  input: string;
  output: string;
  language: Language;
  timestamp: Date;
}

interface ModeConfig {
  id: AIMode;
  label: string;
  icon: React.ElementType;
  placeholder: string;
  description: string;
}

const modes: ModeConfig[] = [
  { 
    id: 'explain', 
    label: 'Explain Code', 
    icon: MessageSquare, 
    placeholder: 'Paste code to explain...',
    description: 'Get a detailed explanation of how the code works'
  },
  { 
    id: 'refactor', 
    label: 'Improve Code', 
    icon: Wand2, 
    placeholder: 'Paste code to improve...',
    description: 'Get suggestions for cleaner, more efficient code'
  },
  { 
    id: 'generate', 
    label: 'Generate Code', 
    icon: FileCode, 
    placeholder: 'Describe what you need...',
    description: 'Generate code from a natural language description'
  },
  { 
    id: 'debug', 
    label: 'Debug', 
    icon: Bug, 
    placeholder: 'Paste code with errors...',
    description: 'Find and fix bugs in your code'
  },
];

const languages: { value: Language; label: string }[] = [
  { value: 'javascript', label: 'JavaScript' },
  { value: 'typescript', label: 'TypeScript' },
  { value: 'python', label: 'Python' },
  { value: 'java', label: 'Java' },
  { value: 'cpp', label: 'C++' },
  { value: 'go', label: 'Go' },
  { value: 'rust', label: 'Rust' },
];

const mockResponses: Record<AIMode, string> = {
  explain: `// Gray Coding Analysis:
// This function calculates the factorial of a number
// using recursion. It multiplies the number by the
// factorial of (n-1) until reaching the base case.
//
// Time Complexity: O(n)
// Space Complexity: O(n) due to call stack

function factorial(n) {
  // Base case: factorial of 0 or 1 is 1
  if (n <= 1) return 1;
  
  // Recursive case: n * factorial(n-1)
  return n * factorial(n - 1);
}`,
  refactor: `// Gray Coding Refactored:
// - Converted to arrow function for cleaner syntax
// - Added input validation
// - Added JSDoc comments
// - Used ternary operator for conciseness

/**
 * Calculates factorial of a number
 * @param {number} n - Non-negative integer
 * @returns {number} - Factorial of n
 * @throws {Error} - If n is negative or not an integer
 */
const factorial = (n) => {
  if (!Number.isInteger(n) || n < 0) {
    throw new Error('Input must be a non-negative integer');
  }
  return n <= 1 ? 1 : n * factorial(n - 1);
};`,
  generate: `// Gray Coding Generated:
// A robust implementation of binary search algorithm
// with TypeScript-style JSDoc comments

/**
 * Performs binary search on a sorted array
 * @param {number[]} arr - Sorted array of numbers
 * @param {number} target - Value to search for
 * @returns {number} - Index of target, or -1 if not found
 */
const binarySearch = (arr, target) => {
  let left = 0;
  let right = arr.length - 1;
  
  while (left <= right) {
    const mid = Math.floor((left + right) / 2);
    
    if (arr[mid] === target) {
      return mid; // Found!
    } else if (arr[mid] < target) {
      left = mid + 1; // Search right half
    } else {
      right = mid - 1; // Search left half
    }
  }
  
  return -1; // Not found
};

// Usage example:
// const sorted = [1, 3, 5, 7, 9, 11, 13];
// binarySearch(sorted, 7); // Returns 3`,
  debug: `// Gray Coding Debug Analysis:
// Issue: The function doesn't handle edge cases properly
//
// Problems found:
// 1. No validation for array input
// 2. No handling for empty arrays
// 3. Potential infinite loop if array is not sorted
//
// Fixed version:

const findMax = (arr) => {
  // Validate input
  if (!Array.isArray(arr) || arr.length === 0) {
    throw new Error('Input must be a non-empty array');
  }
  
  // Check if all elements are numbers
  if (!arr.every(x => typeof x === 'number')) {
    throw new Error('All elements must be numbers');
  }
  
  return Math.max(...arr);
};`,
};

export function AssistantPage() {
  const [activeMode, setActiveMode] = useState<AIMode>('explain');
  const [selectedLanguage, setSelectedLanguage] = useState<Language>('javascript');
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [history, setHistory] = useState<ChatMessage[]>([]);
  const [showHistory, setShowHistory] = useState(true);
  const outputRef = useRef<HTMLDivElement>(null);

  // Load history from localStorage on mount
  useEffect(() => {
    const saved = localStorage.getItem('gray-coding-history');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        setHistory(parsed.map((h: ChatMessage) => ({
          ...h,
          timestamp: new Date(h.timestamp)
        })));
      } catch {
        console.error('Failed to parse history');
      }
    }
  }, []);

  // Save history to localStorage
  useEffect(() => {
    localStorage.setItem('gray-coding-history', JSON.stringify(history));
  }, [history]);

  const handleSubmit = async () => {
    if (!input.trim()) return;
    
    setIsLoading(true);
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const output = mockResponses[activeMode];
    const newMessage: ChatMessage = {
      id: Date.now().toString(),
      mode: activeMode,
      input: input.trim(),
      output,
      language: selectedLanguage,
      timestamp: new Date(),
    };
    
    setHistory(prev => [newMessage, ...prev]);
    setIsLoading(false);
    
    // Scroll to output
    setTimeout(() => {
      outputRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, 100);
  };

  const clearHistory = () => {
    setHistory([]);
    localStorage.removeItem('gray-coding-history');
  };

  const loadFromHistory = (message: ChatMessage) => {
    setActiveMode(message.mode);
    setSelectedLanguage(message.language);
    setInput(message.input);
  };

  const currentMode = modes.find(m => m.id === activeMode);
  const latestOutput = history[0]?.output;

  return (
    <div className="min-h-screen pt-20 pb-8 bg-[#070A12]">
      <div className="max-w-7xl mx-auto px-4 lg:px-8">
        <div className="flex flex-col lg:flex-row gap-6">
          {/* Sidebar - History */}
          <div className={`lg:w-80 flex-shrink-0 ${showHistory ? 'block' : 'hidden lg:block'}`}>
            <div className="code-card sticky top-24">
              <div className="code-header flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <History className="w-4 h-4 text-[#2AFC9A]" />
                  <span className="text-sm text-white/50">History</span>
                </div>
                {history.length > 0 && (
                  <button
                    onClick={clearHistory}
                    className="p-1.5 rounded hover:bg-white/10 transition-colors"
                    title="Clear history"
                  >
                    <Trash2 className="w-4 h-4 text-white/50" />
                  </button>
                )}
              </div>
              <div className="max-h-[calc(100vh-200px)] overflow-auto">
                {history.length === 0 ? (
                  <div className="p-4 text-center">
                    <p className="text-white/40 text-sm">No history yet</p>
                  </div>
                ) : (
                  <div className="divide-y divide-white/5">
                    {history.map((message) => {
                      const ModeIcon = modes.find(m => m.id === message.mode)?.icon || MessageSquare;
                      return (
                        <button
                          key={message.id}
                          onClick={() => loadFromHistory(message)}
                          className="w-full p-4 text-left hover:bg-white/5 transition-colors"
                        >
                          <div className="flex items-center gap-2 mb-2">
                            <ModeIcon className="w-4 h-4 text-[#2AFC9A]" />
                            <span className="text-xs text-white/50 capitalize">{message.mode}</span>
                            <span className="text-xs text-white/30 ml-auto">
                              {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </span>
                          </div>
                          <p className="text-sm text-white/70 truncate">
                            {message.input.slice(0, 60)}...
                          </p>
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="flex-1">
            {/* Page Header */}
            <div className="mb-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 rounded-xl bg-[#2AFC9A]/10 flex items-center justify-center">
                    <Sparkles className="w-5 h-5 text-[#2AFC9A]" />
                  </div>
                  <div>
                    <h1 className="text-2xl font-bold text-white">AI Assistant</h1>
                    <p className="text-white/50 text-sm">Your AI-powered coding companion</p>
                  </div>
                </div>
                <button
                  onClick={() => setShowHistory(!showHistory)}
                  className="lg:hidden p-2 bg-white/5 rounded-lg text-white/50 hover:text-white hover:bg-white/10 transition-colors"
                >
                  <History className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Mode Selector */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-6">
              {modes.map((mode) => (
                <button
                  key={mode.id}
                  onClick={() => {
                    setActiveMode(mode.id);
                    setInput('');
                  }}
                  className={`p-4 rounded-xl border transition-all text-left ${
                    activeMode === mode.id
                      ? 'border-[#2AFC9A]/50 bg-[#2AFC9A]/10'
                      : 'border-white/10 bg-white/5 hover:bg-white/10'
                  }`}
                >
                  <mode.icon className={`w-5 h-5 mb-2 ${
                    activeMode === mode.id ? 'text-[#2AFC9A]' : 'text-white/50'
                  }`} />
                  <p className={`font-medium text-sm ${
                    activeMode === mode.id ? 'text-white' : 'text-white/70'
                  }`}>
                    {mode.label}
                  </p>
                  <p className="text-xs text-white/40 mt-1 hidden sm:block">
                    {mode.description}
                  </p>
                </button>
              ))}
            </div>

            {/* Language Selector */}
            <div className="mb-6">
              <label className="text-sm text-white/50 mb-2 block">Language</label>
              <div className="relative">
                <select
                  value={selectedLanguage}
                  onChange={(e) => setSelectedLanguage(e.target.value as Language)}
                  className="w-full sm:w-48 appearance-none bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-[#2AFC9A]/50"
                >
                  {languages.map((lang) => (
                    <option key={lang.value} value={lang.value} className="bg-[#0B0F1C]">
                      {lang.label}
                    </option>
                  ))}
                </select>
                <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-white/50 pointer-events-none" />
              </div>
            </div>

            {/* Input Area */}
            <div className="code-card mb-6">
              <div className="code-header">
                <span className="text-sm text-white/50">{currentMode?.label}</span>
              </div>
              <textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder={currentMode?.placeholder}
                className="w-full h-48 bg-transparent p-4 font-mono text-sm text-white placeholder:text-white/30 resize-none focus:outline-none"
              />
              <div className="px-4 pb-4 flex justify-end">
                <button
                  onClick={handleSubmit}
                  disabled={!input.trim() || isLoading}
                  className="flex items-center gap-2 px-6 py-3 bg-[#2AFC9A] text-[#070A12] rounded-xl font-semibold disabled:opacity-50 disabled:cursor-not-allowed hover:bg-[#2AFC9A]/90 transition-colors"
                >
                  {isLoading ? (
                    <div className="w-5 h-5 border-2 border-[#070A12]/30 border-t-[#070A12] rounded-full animate-spin" />
                  ) : (
                    <Send className="w-5 h-5" />
                  )}
                  Ask Gray AI
                </button>
              </div>
            </div>

            {/* Output Area */}
            {latestOutput && (
              <div ref={outputRef} className="code-card">
                <div className="code-header flex items-center justify-between">
                  <span className="text-sm text-white/50">Response</span>
                  <button
                    onClick={async () => {
                      await navigator.clipboard.writeText(latestOutput);
                    }}
                    className="p-1.5 rounded hover:bg-white/10 transition-colors"
                  >
                    <Copy className="w-4 h-4 text-white/50" />
                  </button>
                </div>
                <div className="p-4">
                  <CodeCard 
                    title="Gray Coding Response" 
                    code={latestOutput} 
                  />
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
