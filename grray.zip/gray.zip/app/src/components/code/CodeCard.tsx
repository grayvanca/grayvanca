import { useState } from 'react';
import { Check, Copy } from 'lucide-react';

interface CodeCardProps {
  title: string;
  code: string;
  language?: string;
}

export function CodeCard({ title, code }: CodeCardProps) {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    await navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Simple syntax highlighting
  const highlightCode = (code: string) => {
    return code
      .replace(/(\/\/.*$)/gm, '<span class="token-comment">$1</span>')
      .replace(/\b(function|const|let|var|return|if|else|for|while|class|import|export|from|async|await|try|catch)\b/g, '<span class="token-keyword">$1</span>')
      .replace(/\b([a-zA-Z_][a-zA-Z0-9_]*)\s*(?=\()/g, '<span class="token-function">$1</span>')
      .replace(/('[^']*'|"[^"]*"|`[^`]*`)/g, '<span class="token-string">$1</span>')
      .replace(/\b(\d+)\b/g, '<span class="token-number">$1</span>')
      .replace(/([{}[\]()])/g, '<span class="token-operator">$1</span>')
      .replace(/(=>|===|==|!=|!==|&&|\|\||[+\-*/=<>!&|])/g, '<span class="token-operator">$1</span>');
  };

  return (
    <div className="code-card w-full">
      <div className="code-header flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="code-dot bg-red-500/80" />
          <div className="code-dot bg-yellow-500/80" />
          <div className="code-dot bg-green-500/80" />
          <span className="ml-2 text-xs text-white/50 font-mono">{title}</span>
        </div>
        <button
          onClick={handleCopy}
          className="p-1.5 rounded-lg hover:bg-white/10 transition-colors"
          title="Copy code"
        >
          {copied ? (
            <Check className="w-4 h-4 text-[#2AFC9A]" />
          ) : (
            <Copy className="w-4 h-4 text-white/50" />
          )}
        </button>
      </div>
      <div className="code-content">
        <pre dangerouslySetInnerHTML={{ __html: highlightCode(code) }} />
      </div>
    </div>
  );
}
