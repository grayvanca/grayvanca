import { useEffect, useRef } from 'react';

export function AuroraBackground() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationId: number;
    let time = 0;

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    resize();
    window.addEventListener('resize', resize);

    // Aurora colors
    const colors = [
      { r: 42, g: 252, b: 154 },   // Electric mint
      { r: 0, g: 212, b: 255 },    // Cyan
      { r: 100, g: 200, b: 255 },  // Light blue
      { r: 42, g: 180, b: 120 },   // Darker mint
    ];

    const drawAurora = () => {
      time += 0.003;

      // Clear with base color
      ctx.fillStyle = '#070A12';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Draw aurora layers
      for (let i = 0; i < 4; i++) {
        const color = colors[i];
        const offset = i * Math.PI / 2;
        
        // Create gradient
        const gradient = ctx.createRadialGradient(
          canvas.width * (0.3 + 0.4 * Math.sin(time + offset)),
          canvas.height * (0.3 + 0.3 * Math.cos(time * 0.7 + offset)),
          0,
          canvas.width * (0.3 + 0.4 * Math.sin(time + offset)),
          canvas.height * (0.3 + 0.3 * Math.cos(time * 0.7 + offset)),
          canvas.width * 0.6
        );

        gradient.addColorStop(0, `rgba(${color.r}, ${color.g}, ${color.b}, ${0.15 - i * 0.02})`);
        gradient.addColorStop(0.5, `rgba(${color.r}, ${color.g}, ${color.b}, ${0.08 - i * 0.015})`);
        gradient.addColorStop(1, 'transparent');

        ctx.fillStyle = gradient;
        ctx.fillRect(0, 0, canvas.width, canvas.height);
      }

      // Add second set of aurora waves
      for (let i = 0; i < 3; i++) {
        const color = colors[(i + 2) % colors.length];
        const offset = i * Math.PI / 3 + Math.PI;

        const gradient = ctx.createRadialGradient(
          canvas.width * (0.7 + 0.3 * Math.sin(time * 0.8 + offset)),
          canvas.height * (0.6 + 0.2 * Math.cos(time * 0.6 + offset)),
          0,
          canvas.width * (0.7 + 0.3 * Math.sin(time * 0.8 + offset)),
          canvas.height * (0.6 + 0.2 * Math.cos(time * 0.6 + offset)),
          canvas.width * 0.5
        );

        gradient.addColorStop(0, `rgba(${color.r}, ${color.g}, ${color.b}, 0.1)`);
        gradient.addColorStop(0.6, `rgba(${color.r}, ${color.g}, ${color.b}, 0.05)`);
        gradient.addColorStop(1, 'transparent');

        ctx.fillStyle = gradient;
        ctx.fillRect(0, 0, canvas.width, canvas.height);
      }

      animationId = requestAnimationFrame(drawAurora);
    };

    drawAurora();

    return () => {
      window.removeEventListener('resize', resize);
      cancelAnimationFrame(animationId);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 w-full h-full -z-10"
      style={{ background: '#070A12' }}
    />
  );
}
